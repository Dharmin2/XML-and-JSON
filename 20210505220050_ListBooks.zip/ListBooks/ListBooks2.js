// All scripts must occur only after the entire document has been loaded:

// at least one number, one special character, one lowercase and one uppercase letter and at least eight characters 
// here is the regular expression:  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;
$(document).ready(function(){
	getXMLData();
	setCookie();
	getJSONData();
	console.log(getCookieData());
/* 	Get the password value & Verify the password against the regular expression
	each time the user enters a character.
	Then , call the "manageIcon" function to display the check icon if the password matches the 
	regular expression and show the circle icon when it doesn't
	*/
	var password = document.getElementsByTagName('input')[0];
	password.addEventListener('keyup', function(){manageIcon(checkPassword());});
});
/*
- Use an AJAX call to retrieve the "bookstore.xml" file data
- Add all the titles to the dropdown :
	- Each of the dropdown option element should have as a value, the "Category" of the book and the title of the book as its content
	*/
	function getXMLData(){
		var xmlRequest = new XMLHttpRequest();
		var xmlList = document.getElementById("divSelect");
		xmlRequest.open('Get','bookstore.xml',false);
		xmlRequest.send();
		var xmlData = xmlRequest.responseText;
		parser = new DOMParser();
		var xmlDoc = parser.parseFromString(xmlData,"text/xml");
		var titles = xmlDoc.getElementsByTagName("title");
		var categories = xmlDoc.getElementsByTagName("book");
		for (var i = 0; i < 4; i++) {
			var option = document.createElement("option");
			option.value = categories[i].getAttribute('category');
			option.text = titles[i].textContent;
			xmlList.add(option);
		}
	}

/*
- Use an AJAX call to retrieve the "bookstore.json" file data
- Add all the titles to the dropdown :
	- Each of the dropdown options should have as a value, the Category of the book
	*/
	function getJSONData(){
		$.get("bookstore.json", function(response) {
			//console.log(response.bookstore.book[0]);
			var jsonList = document.getElementById("divSelectJSON");
			var data = [];
			temp = response;
			data = response;
			//console.log(data.bookstore.book[0].title["#text"]);
			//console.log(data.bookstore.book[0].title["#-category"]);
			for (var i = 0; i < 4; i++) {
				var option = document.createElement("option");
				jsonList.add(option);
				option.text = data.bookstore.book[i].title["#text"];
				option.value = data.bookstore.book[i]["-category"];
				//option.value = data.bookstore.book[i].title["#text"];
			}
			//var string = data.bookstore.book[0];
			//console.log(string);
		})
	}


/*
	Ensure that the set cookie lasts 1 week from the time it was set
	Ensure that the set cookie is available to all files from the root's 'ListBooks' folder
	*/
	function setCookie(){
		var data = {name:"Harry Potter", author:"J.K. Rowlings"};
		document.cookie = "name=Hary Potter";
		document.cookie = "author=J.K Rowlings";
		var now = new Date();
		now.setUTCHours(7 * 24);
		document.cookie = "expires = " + now.toUTCString() + ";";
		document.cookie = "path=/;";

	}

/*
	Return the cookie's data as a JavaScript object
	*/
	function getCookieData(){
		var cookies = document.cookie.split(';').map(cookie => cookie.split('='));
		return cookies;
	}

/*
	Return true if str matches the regular expression
	false otherwise
	*/
	function checkPassword(str)
	{
		var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;
		var password = document.getElementsByTagName('input')[0].value;

		if (password.match(regex)) {
			return true;
		}
		return false;
	}

/*
	DO NOT MODIFY THIS FUNCTION
	*/
// bState is a boolean value
//	- if the state is true, show the check icon and hide the circle icon
//	- if the state is false, show the circle icon and hide the check icon
function manageIcon(bState){
	if(bState){
		$("i.fa-times-circle").hide();
		$("i.fa-check").show();
	}
	else{
		$("i.fa-times-circle").show();
		$("i.fa-check").hide();
	}
}

